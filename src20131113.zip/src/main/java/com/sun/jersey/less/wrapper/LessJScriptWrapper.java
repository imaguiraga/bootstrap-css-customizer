package com.sun.jersey.less.wrapper;

public class LessJScriptWrapper {

}
